//
//  DDSearchFieldEditorDelegate.m
//  Duoduo
//
//  Created by zuoye on 14-1-24.
//  Copyright (c) 2014年 zuoye. All rights reserved.
//

#import "DDSearchFieldEditorDelegate.h"

@implementation DDSearchFieldEditorDelegate

- (id)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

-(void)awakeFromNib{
        /*
         rax = [RTXSearchResultWindowController sharedSearchResultWindowController];
         rdx = rdi.searchField;
         rdi = rax;
         rax = [rdi setSearchField:rdx];
         return rax;
         
         */
}

@end
