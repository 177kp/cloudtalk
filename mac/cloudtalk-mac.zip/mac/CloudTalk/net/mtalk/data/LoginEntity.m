/************************************************************
 * @file         LoginEntity.m
 * @author       快刀<kuaidao@mogujie.com>
 * summery       登陆相关的参数
 ************************************************************/

#import "LoginEntity.h"

@implementation LoginEntity


@end