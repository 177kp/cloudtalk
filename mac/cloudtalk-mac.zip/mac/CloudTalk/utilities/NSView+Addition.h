//
//  NSView+Addition.h
//  Duoduo
//
//  Created by 独嘉 on 14-2-21.
//  Copyright (c) 2014年 zuoye. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSView (Addition)

@property (assign)CGFloat x;
@property (assign)CGFloat right;
@property (assign)CGFloat y;
@property (assign)CGFloat up;
@property (assign)CGFloat width;
@property (assign)CGFloat height;

@end
