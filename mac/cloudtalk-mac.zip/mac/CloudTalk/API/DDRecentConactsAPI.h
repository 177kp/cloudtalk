//
//  DDRecentConactsAPI.h
//  Duoduo
//
//  Created by 独嘉 on 14-4-24.
//  Copyright (c) 2014年 zuoye. All rights reserved.
//

#import "DDSuperAPI.h"
@interface DDRecentConactsAPI : DDSuperAPI<DDAPIScheduleProtocol>

@end
