//
//  DDTableView.h
//  Duoduo
//
//  Created by zuoye on 14-1-9.
//  Copyright (c) 2014年 zuoye. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface DDTableView : NSTableView

@property (strong) NSImage *backGroundImage;
@property (assign) BOOL hasCustomGridLine;
@end
