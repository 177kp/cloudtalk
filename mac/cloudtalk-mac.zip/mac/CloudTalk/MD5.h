//
//  MD5.h
//  Pet
//
//  Created by Cecil on 11-1-26.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (MyExtensions)

- (NSString *)md5;
- (NSString *)stringWithPercentEscape;

@end