//
//  DDImageView.h
//  Duoduo
//
//  Created by zuoye on 13-11-29.
//  Copyright (c) 2013年 zuoye. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface DDImageView : NSView

@end
