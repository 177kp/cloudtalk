//
//  DDSearchFieldCell.h
//  Duoduo
//
//  Created by zuoye on 14-1-20.
//  Copyright (c) 2014年 zuoye. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface DDSearchFieldCell : NSSearchFieldCell{
    NSImage *activeImageStrech;
    NSImage *normalImageStrech ;
}

@end
