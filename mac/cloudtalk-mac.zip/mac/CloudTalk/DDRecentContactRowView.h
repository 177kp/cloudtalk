//
//  DDRecentContactRowView.h
//  Duoduo
//
//  Created by 独嘉 on 14-3-12.
//  Copyright (c) 2014年 zuoye. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface DDRecentContactRowView : NSTableRowView

@end
