//
//  DDPreferenceWinController.h
//  Duoduo
//
//  Created by zuoye on 14-2-12.
//  Copyright (c) 2014年 zuoye. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface DDPreferenceWinController : NSWindowController

@end
