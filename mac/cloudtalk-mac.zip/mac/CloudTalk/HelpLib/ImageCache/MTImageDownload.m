#import "MTImageDownload.h"
#import <AFNetworking.h>
#import "DDPathHelp.h"
#import "MTImageCache.h"
@interface MTImageDownload(PrivateAPI)

- (void)p_loadImageWithURL:(NSString*)url completion:(MTDownloadImageCompletion)completion;

- (void)p_addComplection:(MTDownloadImageCompletion)completio forURL:(NSString*)url;

- (void)p_executeCompletionForURL:(NSString*)url image:(NSImage*)image;

@end

@implementation MTImageDownload
{
    NSMutableArray* _downloadingImageUrls;
    NSMutableDictionary* _completions;
}

+ (instancetype)shareInstance
{
    static MTImageDownload* g_imageDownload;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        g_imageDownload = [[MTImageDownload alloc] init];
    });
    return g_imageDownload;
}

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        _downloadingImageUrls = [[NSMutableArray alloc] init];
        _completions = [[NSMutableDictionary alloc] init];
    }
    return self;
}

- (void)loadImageWithURL:(NSString*)url completion:(MTDownloadImageCompletion)completion
{
    if (![[_completions allKeys] containsObject:url])
    {
        [self p_addComplection:completion forURL:url];
        [self p_loadImageWithURL:url completion:completion];
    }
    else
    {
        [self p_addComplection:completion forURL:url];
    }
}

- (void)loadFileWithURL:(NSString*)url completion:(MTDownloadFileCompletion)completion
{
    if (url==nil || [url isEqualToString:@""])
    {
        return;
    }
    
    if ([_downloadingImageUrls containsObject:url])
    {
        return;
    }
        
        AFHTTPSessionManager *session=[AFHTTPSessionManager manager];
        session.requestSerializer= [AFHTTPRequestSerializer serializer];
        session.responseSerializer= [AFHTTPResponseSerializer serializer];
        NSURLRequest *request=[NSURLRequest requestWithURL:[NSURL URLWithString:url]];
    
        NSURLSessionDownloadTask* task=[session downloadTaskWithRequest:request progress:^(NSProgress * _Nonnull downloadProgress) {
        } destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
            
            //下载到哪个文件夹
//            NSString* fileName2 = [[url componentsSeparatedByString:@"/"] lastObject];
//            NSString* targetFilePath = [[DDPathHelp imageCachePath] stringByAppendingPathComponent:fileName];
//            return [NSURL URLWithString:targetFilePath];
            //下载到哪个文件夹
            NSString *cachePath=NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).firstObject;
            NSString *fileName=[cachePath stringByAppendingPathComponent:response.suggestedFilename];
            return [NSURL fileURLWithPath:fileName];
            
        } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
            //下载完成了
            NSLog(@"loadFileWithURL下载完成了 %@",(NSString*)filePath);
            [[MTImageCache shareInstance] cacheImageFilePath:(NSString*)filePath forKey:url];
        }];
        [task resume];
}

#pragma mark -
#pragma mark PrivateAPI
- (void)p_loadImageWithURL:(NSString*)url completion:(MTDownloadImageCompletion)completion
{
    if (url==nil || [url isEqualToString:@""])
    {
        return;
    }
    
    if ([_downloadingImageUrls containsObject:url])
    {
        return;
    }
    //下载图片文件。然后保存到缓存目录
    __weak MTImageDownload* weakSelf = self;
    AFHTTPSessionManager *session=[AFHTTPSessionManager manager];
    NSURLRequest *request=[NSURLRequest requestWithURL:[NSURL URLWithString:url]];
    NSURLSessionDownloadTask* task=[session downloadTaskWithRequest:request progress:^(NSProgress * _Nonnull downloadProgress) {
    } destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
        NSString *cachePath=NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).firstObject;
        NSString *fileName=[cachePath stringByAppendingPathComponent:response.suggestedFilename];
        return [NSURL fileURLWithPath:fileName];
    } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
        NSData *data=[[NSData alloc] initWithContentsOfFile:(NSString*)filePath];
        NSImage *img = [[NSImage alloc]initWithData:data];
        [weakSelf p_executeCompletionForURL:url image:img];
        NSLog(@"p_loadImageWithURL下载完成了 %@",filePath);
    }];
    [task resume];
    
}

- (void)p_addComplection:(MTDownloadImageCompletion)completion forURL:(NSString*)url
{
    if ([[_completions allKeys] containsObject:url])
    {
        NSMutableArray* completions = _completions[url];
        [completions addObject:[completion copy]];
    }
    else
    {
        NSMutableArray* completions = [[NSMutableArray alloc] init];
        [completions addObject:[completion copy]];
        [_completions setObject:completions forKey:url];
    }
}

- (void)p_executeCompletionForURL:(NSString*)url image:(NSImage*)image
{
    if ([[_completions allKeys] containsObject:url])
    {
        NSMutableArray* completions = _completions[url];
        for (NSInteger index = 0; index < [completions count]; index ++)
        {
            MTDownloadImageCompletion completion = completions[index];
            completion(image);
        }
    }
}
@end
