#import "MASShortcutView.h"

@interface MASShortcutView (UserDefaults)

@property (nonatomic, copy) NSString *associatedUserDefaultsKey;

@end
