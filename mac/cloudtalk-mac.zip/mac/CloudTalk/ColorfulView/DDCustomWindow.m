//
//  DDCustomWindow.m
//  Duoduo
//
//  Created by 独嘉 on 14-5-4.
//  Copyright (c) 2014年 zuoye. All rights reserved.
//

#import "DDCustomWindow.h"

@implementation DDCustomWindow
- (BOOL)canBecomeKeyWindow
{
    return YES;
}
@end
