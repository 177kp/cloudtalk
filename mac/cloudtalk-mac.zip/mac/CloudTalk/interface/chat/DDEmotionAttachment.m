//
//  DDEmotionAttachment.m
//  Duoduo
//
//  Created by zuoye on 14-1-22.
//  Copyright (c) 2014年 zuoye. All rights reserved.
//

#import "DDEmotionAttachment.h"

@implementation DDEmotionAttachment
@synthesize emotionFileName;
@synthesize emotionPath;
@synthesize emotionText;



@end
