//
//  DDmageSpreadView.h
//  Duoduo
//
//  Created by zuoye on 13-11-29.
//  Copyright (c) 2013年 zuoye. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface DDImageSpreadView : NSView
//@property NSRect preferredBounds;
@property NSImage *backgroundImage;
@end
