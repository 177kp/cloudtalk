/************************************************************
 * @file         FileTansferEntity.m
 * @author       快刀<kuaidao@mogujie.com>
 * summery       文件传输参数
 ************************************************************/

#import "FileTransferEntity.h"

@implementation FileTransferEntity

@end
