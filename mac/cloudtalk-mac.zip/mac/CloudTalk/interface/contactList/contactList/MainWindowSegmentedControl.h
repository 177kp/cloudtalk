//
//  MainWindowSegmentedControl.h
//  TabItem
//
//  Created by zuoye on 13-12-25.
//  Copyright (c) 2013年 zuoye. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface MainWindowSegmentedControl : NSSegmentedControl

@end
