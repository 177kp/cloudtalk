//
//  DDChattingMyLine.h
//  Duoduo
//
//  Created by 东邪 on 14-5-14.
//  Copyright (c) 2014年 zuoye. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface DDChattingMyLine : NSView
@property(nonatomic,strong)NSColor * mBackgroundColor;
-(void)setBackgroundColor:(NSColor *)color;
-(void)setBackgroundImage:(NSImage *)image;
@end
