//
//  DDEmotionAttachment.h
//  Duoduo
//
//  Created by zuoye on 14-1-22.
//  Copyright (c) 2014年 zuoye. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface DDEmotionAttachment : NSTextAttachment


@property (strong)NSString *emotionFileName;
@property (strong)NSString *emotionPath;
@property (strong)NSString *emotionText;
@end
