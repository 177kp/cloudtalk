//
//  DDMainUIController.h
//  Duoduo
//
//  Created by zuoye on 13-12-4.
//  Copyright (c) 2013年 zuoye. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DDMainWindowControllerProtocol.h"

@interface DDMainUIController : NSObject<DDMainWindowControllerProtocol>

@end
