//
//  DDSharedDuoduo.h
//  Duoduo
//
//  Created by maye on 13-10-30.
//  Copyright (c) 2013年 zuoye. All rights reserved.
//

#import "DDDuoduoProtocol.h"

extern id<DDDuoduoProtocol> duoduo;

void setSharedDuoduo(id<DDDuoduoProtocol> shared);