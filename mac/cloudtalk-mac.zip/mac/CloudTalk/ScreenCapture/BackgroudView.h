//
//  BackgroudView.h
//  Duoduo
//
//  Created by jianqing.du on 14-3-26.
//  Copyright (c) 2014年 zuoye. All rights reserved.
//

#import <Cocoa/Cocoa.h>

/*
 * display black background after screen capture buttons
 */
@interface BackgroudView : NSView

@end
