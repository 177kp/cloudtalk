//
//  DDAnimatingListOutlineView.h
//  Duoduo
//
//  Created by zuoye on 13-11-27.
//  Copyright (c) 2013年 zuoye. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DDListOutlineView.h"

@interface DDAnimatingListOutlineView : DDListOutlineView

@end
