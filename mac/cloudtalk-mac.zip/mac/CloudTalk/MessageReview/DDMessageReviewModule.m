//
//  DDMessageReviewModule.m
//  Duoduo
//
//  Created by 独嘉 on 14-4-18.
//  Copyright (c) 2014年 zuoye. All rights reserved.
//

#import "DDMessageReviewModule.h"
@implementation DDMessageReviewModule

- (NSArray*)allSession
{
    return nil;
}

- (NSArray*)messagesForSessionID:(NSString*)sessionID page:(NSInteger)page
{
    return nil;
}

@end
