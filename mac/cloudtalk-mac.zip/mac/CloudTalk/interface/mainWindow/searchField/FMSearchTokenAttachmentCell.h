//
//  FMSearchTokenAttachmentCell.h
//  Duoduo
//
//  Created by zuoye on 14-1-23.
//  Copyright (c) 2014年 zuoye. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface FMSearchTokenAttachmentCell : NSTokenFieldCell



@end
