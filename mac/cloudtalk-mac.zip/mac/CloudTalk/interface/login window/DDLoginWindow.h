//
//  DDLoginWindow.h
//  Duoduo
//
//  Created by jianqing.du on 14-2-17.
//  Copyright (c) 2014年 zuoye. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "DDLoginWindowController.h"

@interface DDLoginWindow : NSWindow

@property DDLoginWindowController *loginWindowController;

@end
